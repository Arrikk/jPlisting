<?php
use Core\View;

View::component('chat/ai');