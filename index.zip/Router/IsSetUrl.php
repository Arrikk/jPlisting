<?php

use Router\ApiUrl;

$url = json_encode(ApiUrl::$url);

?>