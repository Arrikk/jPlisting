<?php

use Core\View;

View::component('inventory/recipe');