<div class="col-lg-6 col-md-6">
    <div class="card">
        <div class="card-header">
            <div>
                <h6 class="card-title mb-0">P&L</h6>
                <small class="text-muted">Show Profiy/Loss per month</small>
            </div>
        </div>
        <div class="card-body">
            <!-- <div class="btn-group" role="group">
                <input type="radio" class="btn-check" name="btnradio" id="btnradio1">
                <label class="btn btn-sm btn-outline-secondary" for="btnradio1">Week</label>
                <input type="radio" class="btn-check" name="btnradio" id="btnradio2">
                <label class="btn btn-sm btn-outline-secondary" for="btnradio2">Month</label>
                <input type="radio" class="btn-check" name="btnradio" id="btnradio3" checked="">
                <label class="btn btn-sm btn-outline-secondary" for="btnradio3">Year</label>
            </div> -->
            <div id="profit-loss"></div>
        </div>
    </div> <!-- .card end -->
</div>