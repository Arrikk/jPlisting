<?php
use Core\View;

View::component('/hr/schedule');
View::component('/hr/script');