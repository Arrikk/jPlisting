<div class="col-lg-12 col-md-12">
    <div class="card">
        <div class="card-header">
            <div>
                <h6 class="card-title mb-0">Sales Trend and Forecasting</h6>
                <!-- <small class="text-muted">Or you can <a href="analytics.html#">sync data to Dashboard</a> to ensure your data is always up-to-date.</small> -->
            </div>
        </div>
        <div class="card-body">
            <div id="sales_trend_forcasting"></div>
        </div>
    </div> <!-- .card end -->
</div>