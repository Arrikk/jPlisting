<?php

use Core\View;

View::component('inventory/invoice');