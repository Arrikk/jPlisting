<?php
namespace Router;

class ApiUrl{

    public static $url = [
        'fetch' => '/user/manufactured',
        'user' => '/iscoming/is/matter'
    ];
}