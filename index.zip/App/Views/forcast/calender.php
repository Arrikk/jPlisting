<?php

use Core\View;

View::component('/forcast/calender');