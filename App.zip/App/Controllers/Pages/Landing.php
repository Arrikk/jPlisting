<?php
namespace App\Controllers\Pages;

class Landing {

    

}