<div class="col-lg-6 col-md-12">
        <div class="card">
            <div class="card-header">
                <h6 class="card-title m-0">Weekly Labor Need Forecast</h6>
            </div>
            <div class="card-body">
                <div id="labor-need-chart"></div>
            </div>
        </div> <!-- .card end -->
</div>