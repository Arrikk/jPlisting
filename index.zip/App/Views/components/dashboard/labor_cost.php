<div class="col-lg-8 col-md-12">
    <div class="card">
        <div class="card-header">
            <div>
                <h6 class="card-title mb-0">Labor Cost</h6>
                <small class="text-muted">with employee positions for both back
                of house and front of house staff.</small>
            </div>
        </div>
        <div class="card-body">
            <!-- <div class="btn-group" role="group">
                <input type="radio" class="btn-check" name="btnradio" id="btnradio1">
                <label class="btn btn-sm btn-outline-secondary" for="btnradio1">Week</label>
                <input type="radio" class="btn-check" name="btnradio" id="btnradio2">
                <label class="btn btn-sm btn-outline-secondary" for="btnradio2">Month</label>
                <input type="radio" class="btn-check" name="btnradio" id="btnradio3" checked="">
                <label class="btn btn-sm btn-outline-secondary" for="btnradio3">Year</label>
            </div> -->
            <div id="apex-labour-cost"></div>
        </div>
    </div> <!-- .card end -->
</div>