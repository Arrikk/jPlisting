<?php
namespace App\Controllers\Pages;

use Core\View;

class Admin {

    // public function sales(){
    //     View::draw('forcast/sales');
    // }
    
}