<?php
namespace App\Models;

use Core\Model\Model;

class Valuation extends Model
{
    
}