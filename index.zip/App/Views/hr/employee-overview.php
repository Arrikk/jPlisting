<?php
use Core\View;

View::component('/hr/overview');