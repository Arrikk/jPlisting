<?php

use Core\View;

echo "<div class=\"row g-3 row-deck\">";
View::component('forcast/sales');
View::component('forcast/sales_analytics');
echo "<div>";