<?php

use Core\View;

echo "<div class=\"row g-3 row-deck\">";
    View::component('forcast/inventory_demand');
echo "<div>";