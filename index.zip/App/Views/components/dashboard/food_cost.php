<div class="col-xl-4 col-lg-4 col-md-4">
    <div class="card">
        <div class="card-header">
            <h6 class="card-title m-0">Realtime Food Cost</h6>
        </div>
        <table id="myDataTable_no_filter" class="table myDataTable card-table mb-0">
            <thead>
                <tr>
                    <th>Food</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Potato</td>
                    <td>$232</td>
                </tr>
                <tr>
                    <td>Tomato</td>
                    <td>$323</td>
                </tr>
                <tr>
                    <td>Cassava</td>
                    <td>$342</td>
                </tr>
                <tr>
                    <td>Millet</td>
                    <td>$136</td>
                </tr>
                <tr>
                    <td>Maize</td>
                    <td>$918</td>
                </tr>
            </tbody>
        </table>
    </div> <!-- .card end -->
</div>